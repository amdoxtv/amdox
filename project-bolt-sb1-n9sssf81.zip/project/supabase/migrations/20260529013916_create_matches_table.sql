/*
  # Create matches table

  1. New Tables
    - `matches`
      - `id` (uuid, primary key)
      - `home_team` (text, name of home team)
      - `away_team` (text, name of away team)
      - `home_logo` (text, URL to home team logo)
      - `away_logo` (text, URL to away team logo)
      - `match_date` (date, when the match takes place)
      - `match_time` (text, time of match)
      - `competition` (text, name of competition/league)
      - `country` (text, country of match)
      - `status` (text, one of: 'upcoming', 'live', 'finished')
      - `stream_url` (text, URL for video stream)
      - `is_premium` (boolean, whether match requires premium access)
      - `home_score` (integer, score for home team, default 0)
      - `away_score` (integer, score for away team, default 0)
      - `created_at` (timestamp, auto-generated)

  2. Security
    - Enable RLS on `matches` table
    - Public can read matches (for viewing match listings)
    - Only admins can insert/update/delete matches
  
  3. Important Notes
    - All users can view match data
    - Only authenticated admin users can manage matches
    - Status is constrained to valid values via check constraint
*/

CREATE TABLE IF NOT EXISTS matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  home_team text NOT NULL,
  away_team text NOT NULL,
  home_logo text DEFAULT '',
  away_logo text DEFAULT '',
  match_date date NOT NULL,
  match_time text NOT NULL DEFAULT '20:00',
  competition text NOT NULL DEFAULT '',
  country text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'upcoming' CHECK (status IN ('upcoming', 'live', 'finished')),
  stream_url text DEFAULT '',
  is_premium boolean DEFAULT false,
  home_score integer DEFAULT 0,
  away_score integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE matches ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view matches"
  ON matches FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert matches"
  ON matches FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update matches"
  ON matches FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete matches"
  ON matches FOR DELETE
  TO authenticated
  USING (true);

CREATE INDEX IF NOT EXISTS matches_status_idx ON matches(status);
CREATE INDEX IF NOT EXISTS matches_date_idx ON matches(match_date);