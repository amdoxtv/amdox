import React, { useState, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { Plus, Edit2, Trash2, X, Calendar, Clock, MapPin, Trophy, Users, Activity, Lock, Unlock } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { Match, MatchStatus } from '../../types/database';
import { Logo } from '../../components/Logo';
import { TableSkeleton } from '../../components/LoadingSkeleton';

interface MatchFormData {
  home_team: string;
  away_team: string;
  home_logo: string;
  away_logo: string;
  match_date: string;
  match_time: string;
  competition: string;
  country: string;
  status: MatchStatus;
  stream_url: string;
  is_premium: boolean;
  home_score: number;
  away_score: number;
}

const initialFormData: MatchFormData = {
  home_team: '',
  away_team: '',
  home_logo: '',
  away_logo: '',
  match_date: new Date().toISOString().split('T')[0],
  match_time: '20:00',
  competition: '',
  country: '',
  status: 'upcoming',
  stream_url: '',
  is_premium: false,
  home_score: 0,
  away_score: 0,
};

export function AdminDashboardPage() {
  const { user, loading: authLoading, signOut } = useAuth();
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingMatch, setEditingMatch] = useState<Match | null>(null);
  const [formData, setFormData] = useState<MatchFormData>(initialFormData);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (user) {
      fetchMatches();
    }
  }, [user]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/admin/login" replace />;
  }

  async function fetchMatches() {
    try {
      const { data } = await supabase
        .from('matches')
        .select('*')
        .order('match_date', { ascending: false });

      if (data) setMatches(data);
    } catch (error) {
      console.error('Error fetching matches:', error);
    } finally {
      setLoading(false);
    }
  }

  const stats = {
    total: matches.length,
    live: matches.filter(m => m.status === 'live').length,
    upcoming: matches.filter(m => m.status === 'upcoming').length,
    premium: matches.filter(m => m.is_premium).length,
  };

  function openAddModal() {
    setEditingMatch(null);
    setFormData(initialFormData);
    setShowModal(true);
  }

  function openEditModal(match: Match) {
    setEditingMatch(match);
    setFormData({
      home_team: match.home_team,
      away_team: match.away_team,
      home_logo: match.home_logo,
      away_logo: match.away_logo,
      match_date: match.match_date,
      match_time: match.match_time,
      competition: match.competition,
      country: match.country,
      status: match.status,
      stream_url: match.stream_url,
      is_premium: match.is_premium,
      home_score: match.home_score,
      away_score: match.away_score,
    });
    setShowModal(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);

    try {
      if (editingMatch) {
        const { error } = await supabase
          .from('matches')
          .update(formData)
          .eq('id', editingMatch.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('matches')
          .insert([formData]);

        if (error) throw error;
      }

      await fetchMatches();
      setShowModal(false);
      setFormData(initialFormData);
      setEditingMatch(null);
    } catch (error) {
      console.error('Error saving match:', error);
      alert('Failed to save match. Please try again.');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    try {
      const { error } = await supabase
        .from('matches')
        .delete()
        .eq('id', id);

      if (error) throw error;
      await fetchMatches();
      setDeleteConfirm(null);
    } catch (error) {
      console.error('Error deleting match:', error);
      alert('Failed to delete match. Please try again.');
    }
  }

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <nav className="bg-surface/80 backdrop-blur-lg border-b border-white/10 px-4 md:px-8 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Logo size="md" showText={false} />
          <div className="flex items-center gap-4">
            <span className="text-sm font-body text-gray-300 hidden md:block">
              {user.email}
            </span>
            <button
              onClick={signOut}
              className="bg-red-500/20 hover:bg-red-500/30 text-red-400 px-4 py-2 rounded-lg font-body text-sm transition-colors"
            >
              Logout
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 md:px-8 py-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
          <h1 className="font-heading text-3xl font-bold text-white">Admin Dashboard</h1>
          <button
            onClick={openAddModal}
            className="flex items-center gap-2 bg-primary hover:bg-primary/80 text-background px-4 py-2 rounded-lg font-body font-semibold transition-colors"
          >
            <Plus className="w-5 h-5" />
            Add Match
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-surface rounded-xl p-6 border border-white/10">
            <div className="flex items-center gap-3 mb-2">
              <Activity className="w-5 h-5 text-primary" />
              <span className="font-body text-sm text-gray-400">Total</span>
            </div>
            <p className="font-heading text-3xl font-bold text-white">{stats.total}</p>
          </div>

          <div className="bg-surface rounded-xl p-6 border border-white/10">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-2 h-2 bg-live rounded-full animate-pulse-live"></div>
              <span className="font-body text-sm text-gray-400">Live</span>
            </div>
            <p className="font-heading text-3xl font-bold text-live">{stats.live}</p>
          </div>

          <div className="bg-surface rounded-xl p-6 border border-white/10">
            <div className="flex items-center gap-3 mb-2">
              <Calendar className="w-5 h-5 text-accent" />
              <span className="font-body text-sm text-gray-400">Upcoming</span>
            </div>
            <p className="font-heading text-3xl font-bold text-accent">{stats.upcoming}</p>
          </div>

          <div className="bg-surface rounded-xl p-6 border border-white/10">
            <div className="flex items-center gap-3 mb-2">
              <Lock className="w-5 h-5 text-yellow-500" />
              <span className="font-body text-sm text-gray-400">Premium</span>
            </div>
            <p className="font-heading text-3xl font-bold text-yellow-500">{stats.premium}</p>
          </div>
        </div>

        <div className="bg-surface rounded-xl overflow-hidden border border-white/10">
          {loading ? (
            <TableSkeleton rows={5} />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-surface/50 border-b border-white/10">
                    <th className="text-left px-6 py-4 font-body text-xs font-semibold text-gray-400 uppercase">Date</th>
                    <th className="text-left px-6 py-4 font-body text-xs font-semibold text-gray-400 uppercase">Home</th>
                    <th className="text-left px-6 py-4 font-body text-xs font-semibold text-gray-400 uppercase">Away</th>
                    <th className="text-left px-6 py-4 font-body text-xs font-semibold text-gray-400 uppercase">Competition</th>
                    <th className="text-left px-6 py-4 font-body text-xs font-semibold text-gray-400 uppercase">Status</th>
                    <th className="text-left px-6 py-4 font-body text-xs font-semibold text-gray-400 uppercase">Premium</th>
                    <th className="text-right px-6 py-4 font-body text-xs font-semibold text-gray-400 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {matches.map((match) => (
                    <tr key={match.id} className="border-b border-white/5 hover:bg-surface/30 transition-colors">
                      <td className="px-6 py-4 font-body text-sm text-white">
                        {formatDate(match.match_date)}
                      </td>
                      <td className="px-6 py-4 font-body text-sm text-white">
                        {match.home_team}
                      </td>
                      <td className="px-6 py-4 font-body text-sm text-white">
                        {match.away_team}
                      </td>
                      <td className="px-6 py-4 font-body text-sm text-gray-300">
                        {match.competition}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-body font-semibold ${
                          match.status === 'live' ? 'bg-live/20 text-live' :
                          match.status === 'upcoming' ? 'bg-accent/20 text-accent' :
                          'bg-gray-500/20 text-gray-400'
                        }`}>
                          {match.status === 'live' && <span className="w-1.5 h-1.5 bg-live rounded-full animate-pulse-live"></span>}
                          {match.status.toUpperCase()}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        {match.is_premium ? (
                          <Lock className="w-4 h-4 text-yellow-500" />
                        ) : (
                          <Unlock className="w-4 h-4 text-gray-500" />
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => openEditModal(match)}
                            className="p-2 hover:bg-primary/20 rounded-lg transition-colors"
                            title="Edit"
                          >
                            <Edit2 className="w-4 h-4 text-primary" />
                          </button>
                          <button
                            onClick={() => setDeleteConfirm(match.id)}
                            className="p-2 hover:bg-red-500/20 rounded-lg transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4 text-red-400" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {(showModal || deleteConfirm) && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-surface rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            {deleteConfirm ? (
              <div className="p-8">
                <h2 className="font-heading text-2xl font-bold text-white mb-4">Confirm Delete</h2>
                <p className="font-body text-gray-300 mb-6">Are you sure you want to delete this match? This action cannot be undone.</p>
                <div className="flex items-center justify-end gap-3">
                  <button
                    onClick={() => setDeleteConfirm(null)}
                    className="px-4 py-2 bg-gray-500/20 hover:bg-gray-500/30 text-gray-300 rounded-lg font-body transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => handleDelete(deleteConfirm)}
                    className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg font-body transition-colors"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between p-6 border-b border-white/10">
                  <h2 className="font-heading text-2xl font-bold text-white">
                    {editingMatch ? 'Edit Match' : 'Add New Match'}
                  </h2>
                  <button
                    onClick={() => setShowModal(false)}
                    className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                  >
                    <X className="w-5 h-5 text-gray-400" />
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="p-6 space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-body text-sm text-gray-300 mb-2">Home Team</label>
                      <input
                        type="text"
                        value={formData.home_team}
                        onChange={(e) => setFormData({ ...formData, home_team: e.target.value })}
                        className="w-full bg-background border border-white/10 rounded-lg px-4 py-2 font-body text-white focus:outline-none focus:border-primary/50"
                        required
                      />
                    </div>

                    <div>
                      <label className="block font-body text-sm text-gray-300 mb-2">Away Team</label>
                      <input
                        type="text"
                        value={formData.away_team}
                        onChange={(e) => setFormData({ ...formData, away_team: e.target.value })}
                        className="w-full bg-background border border-white/10 rounded-lg px-4 py-2 font-body text-white focus:outline-none focus:border-primary/50"
                        required
                      />
                    </div>

                    <div>
                      <label className="block font-body text-sm text-gray-300 mb-2">Home Logo URL</label>
                      <input
                        type="url"
                        value={formData.home_logo}
                        onChange={(e) => setFormData({ ...formData, home_logo: e.target.value })}
                        className="w-full bg-background border border-white/10 rounded-lg px-4 py-2 font-body text-white focus:outline-none focus:border-primary/50"
                        placeholder="https://..."
                      />
                    </div>

                    <div>
                      <label className="block font-body text-sm text-gray-300 mb-2">Away Logo URL</label>
                      <input
                        type="url"
                        value={formData.away_logo}
                        onChange={(e) => setFormData({ ...formData, away_logo: e.target.value })}
                        className="w-full bg-background border border-white/10 rounded-lg px-4 py-2 font-body text-white focus:outline-none focus:border-primary/50"
                        placeholder="https://..."
                      />
                    </div>

                    <div>
                      <label className="block font-body text-sm text-gray-300 mb-2">Match Date</label>
                      <input
                        type="date"
                        value={formData.match_date}
                        onChange={(e) => setFormData({ ...formData, match_date: e.target.value })}
                        className="w-full bg-background border border-white/10 rounded-lg px-4 py-2 font-body text-white focus:outline-none focus:border-primary/50"
                        required
                      />
                    </div>

                    <div>
                      <label className="block font-body text-sm text-gray-300 mb-2">Match Time</label>
                      <input
                        type="time"
                        value={formData.match_time}
                        onChange={(e) => setFormData({ ...formData, match_time: e.target.value })}
                        className="w-full bg-background border border-white/10 rounded-lg px-4 py-2 font-body text-white focus:outline-none focus:border-primary/50"
                        required
                      />
                    </div>

                    <div>
                      <label className="block font-body text-sm text-gray-300 mb-2">Competition</label>
                      <input
                        type="text"
                        value={formData.competition}
                        onChange={(e) => setFormData({ ...formData, competition: e.target.value })}
                        className="w-full bg-background border border-white/10 rounded-lg px-4 py-2 font-body text-white focus:outline-none focus:border-primary/50"
                        required
                      />
                    </div>

                    <div>
                      <label className="block font-body text-sm text-gray-300 mb-2">Country</label>
                      <input
                        type="text"
                        value={formData.country}
                        onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                        className="w-full bg-background border border-white/10 rounded-lg px-4 py-2 font-body text-white focus:outline-none focus:border-primary/50"
                        required
                      />
                    </div>

                    <div>
                      <label className="block font-body text-sm text-gray-300 mb-2">Status</label>
                      <select
                        value={formData.status}
                        onChange={(e) => setFormData({ ...formData, status: e.target.value as MatchStatus })}
                        className="w-full bg-background border border-white/10 rounded-lg px-4 py-2 font-body text-white focus:outline-none focus:border-primary/50"
                      >
                        <option value="upcoming">Upcoming</option>
                        <option value="live">Live</option>
                        <option value="finished">Finished</option>
                      </select>
                    </div>

                    <div>
                      <label className="block font-body text-sm text-gray-300 mb-2">Stream URL</label>
                      <input
                        type="url"
                        value={formData.stream_url}
                        onChange={(e) => setFormData({ ...formData, stream_url: e.target.value })}
                        className="w-full bg-background border border-white/10 rounded-lg px-4 py-2 font-body text-white focus:outline-none focus:border-primary/50"
                        placeholder="https://..."
                      />
                    </div>

                    <div>
                      <label className="block font-body text-sm text-gray-300 mb-2">Home Score</label>
                      <input
                        type="number"
                        min="0"
                        value={formData.home_score}
                        onChange={(e) => setFormData({ ...formData, home_score: parseInt(e.target.value) || 0 })}
                        className="w-full bg-background border border-white/10 rounded-lg px-4 py-2 font-body text-white focus:outline-none focus:border-primary/50"
                      />
                    </div>

                    <div>
                      <label className="block font-body text-sm text-gray-300 mb-2">Away Score</label>
                      <input
                        type="number"
                        min="0"
                        value={formData.away_score}
                        onChange={(e) => setFormData({ ...formData, away_score: parseInt(e.target.value) || 0 })}
                        className="w-full bg-background border border-white/10 rounded-lg px-4 py-2 font-body text-white focus:outline-none focus:border-primary/50"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, is_premium: !formData.is_premium })}
                      className={`flex items-center gap-2 px-4 py-2 rounded-lg font-body transition-colors ${
                        formData.is_premium
                          ? 'bg-yellow-500/20 text-yellow-500 border border-yellow-500/30'
                          : 'bg-gray-500/20 text-gray-400 border border-gray-500/30'
                      }`}
                    >
                      {formData.is_premium ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                      Premium Match
                    </button>
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
                    <button
                      type="button"
                      onClick={() => setShowModal(false)}
                      className="px-6 py-2 bg-gray-500/20 hover:bg-gray-500/30 text-gray-300 rounded-lg font-body transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={saving}
                      className="px-6 py-2 bg-primary hover:bg-primary/80 disabled:bg-primary/50 text-background rounded-lg font-body font-semibold transition-colors"
                    >
                      {saving ? 'Saving...' : 'Save Match'}
                    </button>
                  </div>
                </form>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
