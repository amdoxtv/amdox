import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Play } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Match } from '../types/database';
import { MatchCard } from '../components/MatchCard';
import { HeroSkeleton, MatchCardSkeleton } from '../components/LoadingSkeleton';

function CountdownTimer({ matchDate, matchTime }: { matchDate: string; matchTime: string }) {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const matchDateTime = new Date(`${matchDate}T${matchTime}:00`);
      const now = new Date();
      const difference = matchDateTime.getTime() - now.getTime();

      if (difference > 0) {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);

        setTimeLeft({ days, hours, minutes, seconds });
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [matchDate, matchTime]);

  const TimeBlock = ({ value, label }: { value: number; label: string }) => (
    <div className="flex flex-col items-center">
      <div className="bg-surface/80 backdrop-blur-sm rounded-lg px-4 py-3 min-w-[60px] md:min-w-[80px] border border-primary/20">
        <span className="font-heading text-2xl md:text-4xl font-bold text-primary">
          {value.toString().padStart(2, '0')}
        </span>
      </div>
      <span className="text-xs md:text-sm text-gray-400 mt-1 font-body">{label}</span>
    </div>
  );

  return (
    <div className="flex items-center gap-2 md:gap-4">
      <TimeBlock value={timeLeft.days} label="Days" />
      <span className="text-primary text-2xl md:text-4xl font-bold">:</span>
      <TimeBlock value={timeLeft.hours} label="Hours" />
      <span className="text-primary text-2xl md:text-4xl font-bold">:</span>
      <TimeBlock value={timeLeft.minutes} label="Min" />
      <span className="text-primary text-2xl md:text-4xl font-bold">:</span>
      <TimeBlock value={timeLeft.seconds} label="Sec" />
    </div>
  );
}

export function HomePage() {
  const [featuredMatch, setFeaturedMatch] = useState<Match | null>(null);
  const [liveMatches, setLiveMatches] = useState<Match[]>([]);
  const [upcomingMatches, setUpcomingMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMatches();

    const channel = supabase
      .channel('matches-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'matches' },
        () => fetchMatches()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  async function fetchMatches() {
    try {
      const { data: featured } = await supabase
        .from('matches')
        .select('*')
        .in('status', ['upcoming', 'live'])
        .order('match_date', { ascending: true })
        .limit(1)
        .maybeSingle();

      if (featured) setFeaturedMatch(featured);

      const { data: live } = await supabase
        .from('matches')
        .select('*')
        .eq('status', 'live')
        .order('match_date', { ascending: true })
        .limit(10);

      if (live) setLiveMatches(live);

      const { data: upcoming } = await supabase
        .from('matches')
        .select('*')
        .eq('status', 'upcoming')
        .order('match_date', { ascending: true })
        .limit(12);

      if (upcoming) setUpcomingMatches(upcoming);
    } catch (error) {
      console.error('Error fetching matches:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen">
        <HeroSkeleton />
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <MatchCardSkeleton key={i} />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {featuredMatch && (
        <div className="relative h-[500px] md:h-[600px] overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-surface/60 to-background"></div>

          <div className="absolute inset-0 flex flex-col items-center justify-center px-4">
            <div className="text-center mb-6">
              <span className="inline-block bg-live/20 text-live px-3 py-1 rounded-full text-sm font-body font-semibold mb-4">
                {featuredMatch.status === 'live' ? 'LIVE NOW' : 'NEXT MATCH'}
              </span>
              <h2 className="text-lg md:text-xl font-body text-gray-300 mb-2">
                {featuredMatch.competition}
              </h2>
            </div>

            <div className="flex items-center justify-center gap-4 md:gap-8 mb-6 w-full max-w-3xl">
              <div className="flex flex-col items-center flex-1">
                {featuredMatch.home_logo ? (
                  <img
                    src={featuredMatch.home_logo}
                    alt={featuredMatch.home_team}
                    className="w-24 h-24 md:w-32 md:h-32 object-contain mb-2"
                  />
                ) : (
                  <div className="w-24 h-24 md:w-32 md:h-32 bg-blue-600 rounded-full flex items-center justify-center mb-2">
                    <span className="text-2xl md:text-3xl font-bold text-white">{
                      featuredMatch.home_team.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 3)
                    }</span>
                  </div>
                )}
                <span className="font-heading text-lg md:text-xl font-semibold text-white">
                  {featuredMatch.home_team}
                </span>
              </div>

              <div className="flex flex-col items-center justify-center">
                {featuredMatch.status === 'live' ? (
                  <div className="flex items-center gap-4">
                    <span className="font-heading text-3xl md:text-4xl font-bold text-white">
                      {featuredMatch.home_score}
                    </span>
                    <span className="text-2xl text-gray-400">-</span>
                    <span className="font-heading text-3xl md:text-4xl font-bold text-white">
                      {featuredMatch.away_score}
                    </span>
                  </div>
                ) : (
                  <Play className="w-12 h-12 md:w-16 md:h-16 text-primary opacity-60" />
                )}
              </div>

              <div className="flex flex-col items-center flex-1">
                {featuredMatch.away_logo ? (
                  <img
                    src={featuredMatch.away_logo}
                    alt={featuredMatch.away_team}
                    className="w-24 h-24 md:w-32 md:h-32 object-contain mb-2"
                  />
                ) : (
                  <div className="w-24 h-24 md:w-32 md:h-32 bg-red-600 rounded-full flex items-center justify-center mb-2">
                    <span className="text-2xl md:text-3xl font-bold text-white">{
                      featuredMatch.away_team.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 3)
                    }</span>
                  </div>
                )}
                <span className="font-heading text-lg md:text-xl font-semibold text-white">
                  {featuredMatch.away_team}
                </span>
              </div>
            </div>

            {featuredMatch.status === 'upcoming' && (
              <div className="mb-4">
                <CountdownTimer matchDate={featuredMatch.match_date} matchTime={featuredMatch.match_time} />
              </div>
            )}

            <Link
              to={`/watch/${featuredMatch.id}`}
              className="bg-primary hover:bg-primary/80 text-background font-body font-semibold px-8 py-3 rounded-lg transition-all hover:shadow-lg hover:shadow-primary/30"
            >
              Watch Now
            </Link>
          </div>
        </div>
      )}

      {liveMatches.length > 0 && (
        <div className="bg-surface/50 py-6">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-3 h-3 bg-live rounded-full animate-pulse-live"></div>
              <h2 className="font-heading text-2xl font-bold text-white">LIVE NOW</h2>
              <span className="font-body text-sm text-gray-400">({liveMatches.length} matches)</span>
            </div>

            <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-4">
              {liveMatches.map((match) => (
                <Link key={match.id} to={`/watch/${match.id}`} className="min-w-[300px] md:min-w-[350px]">
                  <MatchCard match={match} compact />
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-heading text-2xl font-bold text-white">Upcoming Matches</h2>
          <Link
            to="/match"
            className="flex items-center gap-1 text-primary hover:text-accent transition-colors font-body text-sm"
          >
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {upcomingMatches.map((match) => (
            <MatchCard key={match.id} match={match} />
          ))}
        </div>

        {upcomingMatches.length === 0 && (
          <div className="text-center py-12">
            <p className="font-body text-gray-400">No upcoming matches at the moment</p>
          </div>
        )}
      </div>
    </div>
  );
}
