import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Match, MatchStatus } from '../types/database';
import { MatchCard } from '../components/MatchCard';
import { MatchCardSkeleton } from '../components/LoadingSkeleton';

type FilterTab = 'archive' | 'live' | 'upcoming' | 'all';

const filterTabs: { key: FilterTab; label: string; status?: MatchStatus }[] = [
  { key: 'archive', label: 'ARCHIVE', status: 'finished' },
  { key: 'live', label: 'EN DIRECT', status: 'live' },
  { key: 'upcoming', label: 'À VENIR', status: 'upcoming' },
  { key: 'all', label: 'TOUS' },
];

export function MatchesPage() {
  const [activeTab, setActiveTab] = useState<FilterTab>('all');
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);
  const [underlineStyle, setUnderlineStyle] = useState({ left: 0, width: 0 });

  useEffect(() => {
    fetchMatches();

    const channel = supabase
      .channel('matches-page-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'matches' },
        () => fetchMatches()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [activeTab]);

  function updateUnderlineStyle(element: HTMLElement | null) {
    if (element) {
      const parent = element.parentElement;
      if (parent) {
        const parentRect = parent.getBoundingClientRect();
        const elementRect = element.getBoundingClientRect();
        setUnderlineStyle({
          left: elementRect.left - parentRect.left,
          width: elementRect.width,
        });
      }
    }
  }

  async function fetchMatches() {
    setLoading(true);
    try {
      let query = supabase.from('matches').select('*');

      if (activeTab !== 'all') {
        const status = filterTabs.find(t => t.key === activeTab)?.status;
        if (status) {
          query = query.eq('status', status);
        }
      }

      const { data } = await query.order('match_date', { ascending: activeTab !== 'archive' });

      if (data) {
        setMatches(activeTab === 'archive' ? data.reverse() : data);
      }
    } catch (error) {
      console.error('Error fetching matches:', error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="font-heading text-3xl md:text-4xl font-bold text-white mb-8">Matches</h1>

      <div className="relative mb-8">
        <div className="flex gap-4 md:gap-8 overflow-x-auto scrollbar-hide pb-2">
          {filterTabs.map(({ key, label }, index) => {
            const isActive = activeTab === key;
            const count = matches.filter(m => key === 'all' || m.status === filterTabs.find(t => t.key === key)?.status).length;

            return (
              <button
                key={key}
                ref={(el) => {
                  if (isActive && el) {
                    setTimeout(() => updateUnderlineStyle(el), 0);
                  }
                }}
                onClick={() => setActiveTab(key)}
                className={`relative px-4 py-3 font-body font-semibold transition-colors whitespace-nowrap ${
                  isActive ? 'text-primary' : 'text-gray-400 hover:text-white'
                }`}
              >
                <span>{label}</span>
                {isActive && (
                  <div
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary transition-all duration-300"
                    style={{ left: 0, width: '100%' }}
                  />
                )}
              </button>
            );
          })}
        </div>
        <div
          className="absolute bottom-0 h-0.5 bg-primary transition-all duration-300 ease-out"
          style={{
            left: underlineStyle.left,
            width: underlineStyle.width,
          }}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          [...Array(6)].map((_, i) => <MatchCardSkeleton key={i} />)
        ) : matches.length > 0 ? (
          matches.map((match) => <MatchCard key={match.id} match={match} />)
        ) : (
          <div className="col-span-full text-center py-12">
            <p className="font-body text-gray-400">
              No matches found for this filter
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
