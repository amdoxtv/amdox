import React, { useState } from 'react';
import { Calendar, Clock, TrendingUp } from 'lucide-react';
import { NewsItem } from '../types/database';

const sampleNews: NewsItem[] = [
  {
    id: '1',
    title: 'Manchester City Secures Dramatic Late Winner Against Liverpool',
    excerpt: 'A stunning last-minute goal from Erling Haaland gives City a crucial victory in the title race, sending fans into raptures at the Etihad Stadium.',
    image: 'https://images.pexels.com/photos/314845/pexels-photo-314845.jpeg?auto=compress&cs=tinysrgb&w=600',
    date: '2026-05-29',
    category: 'Premier League',
  },
  {
    id: '2',
    title: 'Real Madrid Announces Major Summer Transfer Window Plans',
    excerpt: 'The Spanish giants are preparing for a massive overhaul with several high-profile signings expected to be announced in the coming weeks.',
    image: 'https://images.pexels.com/photos/3693103/pexels-photo-3693103.jpeg?auto=compress&cs=tinysrgb&w=600',
    date: '2026-05-28',
    category: 'Transfer News',
  },
  {
    id: '3',
    title: 'Champions League Final: Complete Guide to the Showpiece Event',
    excerpt: 'Everything you need to know about the biggest club game in world football, including venue, tickets, and broadcast information.',
    image: 'https://images.pexels.com/photos/209283/pexels-photo-209283.jpeg?auto=compress&cs=tinysrgb&w=600',
    date: '2026-05-27',
    category: 'Champions League',
  },
  {
    id: '4',
    title: 'Arsenals Young Stars Shine in Pre-Season Tournament',
    excerpt: 'The Gunners youth academy continues to produce exceptional talent as several teenagers impress in the Emirates Cup.',
    image: 'https://images.pexels.com/photos/136314/pexels-photo-136314.jpeg?auto=compress&cs=tinysrgb&w=600',
    date: '2026-05-26',
    category: 'Arsenal',
  },
  {
    id: '5',
    title: 'VAR Under Scrutiny After Controversial Weekend Decisions',
    excerpt: 'Weekend fixtures saw multiple VAR incidents that have reignited the debate about technology use in football.',
    image: 'https://images.pexels.com/photos/47730/the-ball-stadion-football-the-pitch-47730.jpeg?auto=compress&cs=tinysrgb&w=600',
    date: '2026-05-25',
    category: 'VAR',
  },
  {
    id: '6',
    title: 'Bayern Munichs New Manager Unveiled at Press Conference',
    excerpt: 'The Bundesliga champions introduce their new head coach with ambitious promises for the upcoming season.',
    image: 'https://images.pexels.com/photos/718907/pexels-photo-718907.jpeg?auto=compress&cs=tinysrgb&w=600',
    date: '2026-05-24',
    category: 'Bundesliga',
  },
];

const trendingNews = sampleNews.slice(0, 3);

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

function NewsCard({ news, featured = false }: { news: NewsItem; featured?: boolean }) {
  return (
    <article className={`group cursor-pointer ${featured ? 'mb-6' : ''}`}>
      <div className={`relative overflow-hidden rounded-xl ${featured ? 'h-64 md:h-80' : 'h-48'}`}>
        <img
          src={news.image}
          alt={news.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent"></div>
        <div className="absolute bottom-0 left-0 right-0 p-4 md:p-6">
          <span className="inline-block bg-primary/20 text-primary px-3 py-1 rounded-full text-xs font-body font-semibold mb-2">
            {news.category}
          </span>
          <h3 className={`font-heading font-bold text-white mb-2 ${featured ? 'text-xl md:text-2xl' : 'text-base md:text-lg'} group-hover:text-primary transition-colors`}>
            {news.title}
          </h3>
          <div className="flex items-center gap-3 text-gray-400 text-xs font-body">
            <span className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {formatDate(news.date)}
            </span>
          </div>
        </div>
      </div>
      {!featured && (
        <p className="font-body text-sm text-gray-400 mt-3 line-clamp-2">
          {news.excerpt}
        </p>
      )}
    </article>
  );
}

export function NewsPage() {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', ...new Set(sampleNews.map(n => n.category))];
  const filteredNews = selectedCategory === 'All'
    ? sampleNews
    : sampleNews.filter(n => n.category === selectedCategory);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <h1 className="font-heading text-3xl md:text-4xl font-bold text-white">Latest News</h1>

        <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide pb-2">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-lg font-body text-sm whitespace-nowrap transition-colors ${
                selectedCategory === category
                  ? 'bg-primary text-background'
                  : 'bg-surface text-gray-300 hover:bg-surface/80'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {filteredNews.length > 0 && (
        <div className="mb-8">
          <NewsCard news={filteredNews[0]} featured />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredNews.slice(1).map((news) => (
              <NewsCard key={news.id} news={news} />
            ))}
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-surface rounded-xl p-6 border border-white/10">
            <div className="flex items-center gap-2 mb-6">
              <TrendingUp className="w-5 h-5 text-primary" />
              <h2 className="font-heading text-xl font-bold text-white">Trending</h2>
            </div>

            <div className="space-y-4">
              {trendingNews.map((news, index) => (
                <div key={news.id} className="flex gap-4 group cursor-pointer">
                  <div className="flex-shrink-0 w-8 h-8 bg-primary/20 rounded flex items-center justify-center">
                    <span className="font-heading font-bold text-primary">{index + 1}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-body text-sm text-white group-hover:text-primary transition-colors line-clamp-2">
                      {news.title}
                    </h4>
                    <span className="text-xs text-gray-500 font-body">
                      {formatDate(news.date)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-primary/20 to-surface rounded-xl p-6 border border-primary/30 mt-6">
            <h3 className="font-heading text-lg font-bold text-white mb-2">Subscribe to Newsletter</h3>
            <p className="font-body text-sm text-gray-400 mb-4">Get the latest sports news delivered to your inbox</p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Your email"
                className="flex-1 bg-background border border-white/10 rounded-lg px-3 py-2 font-body text-sm text-white focus:outline-none focus:border-primary/50"
              />
              <button className="bg-primary hover:bg-primary/80 text-background px-4 py-2 rounded-lg font-body font-semibold transition-colors">
                Join
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
