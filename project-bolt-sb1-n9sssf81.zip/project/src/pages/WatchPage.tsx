import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Calendar, MapPin, ArrowLeft } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Match } from '../types/database';
import { MatchCard } from '../components/MatchCard';
import { HeroSkeleton, MatchCardSkeleton } from '../components/LoadingSkeleton';

function WatermarkLogo() {
  return (
    <div
      className="absolute top-3 right-3 z-10 pointer-events-none"
      style={{ opacity: 0.82 }}
    >
      <div className="bg-background rounded-lg border border-primary/30 px-2 py-1">
        <div className="flex flex-col items-center">
          <span className="font-heading font-bold text-primary text-sm">TV</span>
          <span className="font-heading text-accent text-[8px] tracking-wider">AMDOX</span>
        </div>
      </div>
    </div>
  );
}

export function WatchPage() {
  const { id } = useParams();
  const [match, setMatch] = useState<Match | null>(null);
  const [upcomingMatches, setUpcomingMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchMatch();
      fetchUpcomingMatches();

      const channel = supabase
        .channel('match-updates')
        .on(
          'postgres_changes',
          { event: 'UPDATE', schema: 'public', table: 'matches', filter: `id=eq.${id}` },
          (payload) => {
            if (payload.new) {
              setMatch(payload.new as Match);
            }
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [id]);

  async function fetchMatch() {
    try {
      const { data } = await supabase
        .from('matches')
        .select('*')
        .eq('id', id)
        .maybeSingle();

      if (data) setMatch(data);
    } catch (error) {
      console.error('Error fetching match:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchUpcomingMatches() {
    try {
      const { data } = await supabase
        .from('matches')
        .select('*')
        .eq('status', 'upcoming')
        .neq('id', id)
        .order('match_date', { ascending: true })
        .limit(5);

      if (data) setUpcomingMatches(data);
    } catch (error) {
      console.error('Error fetching upcoming matches:', error);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <HeroSkeleton />
      </div>
    );
  }

  if (!match) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 text-center">
        <h1 className="font-heading text-3xl font-bold text-white mb-4">Match not found</h1>
        <Link to="/" className="text-primary hover:text-accent transition-colors">
          Return to home
        </Link>
      </div>
    );
  }

  const isLive = match.status === 'live';

  return (
    <div className="min-h-screen bg-background">
      <div className="relative w-full aspect-video bg-surface">
        {match.stream_url ? (
          <>
            <iframe
              src={match.stream_url}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
            <WatermarkLogo />
          </>
        ) : (
          <div className="absolute inset-0 flex items-center justify-center">
            <p className="font-body text-gray-400">Stream not available</p>
          </div>
        )}

        <div className="absolute top-4 left-4 z-20">
          <Link
            to="/"
            className="flex items-center gap-2 bg-surface/90 backdrop-blur-sm px-4 py-2 rounded-lg hover:bg-surface transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-primary" />
            <span className="font-body text-sm text-white">Back</span>
          </Link>
        </div>

        {isLive && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2 bg-live/90 backdrop-blur-sm px-4 py-2 rounded-lg">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse-live"></div>
            <span className="font-body font-bold text-white text-sm">LIVE</span>
          </div>
        )}
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="flex-1">
            <div className="bg-surface rounded-xl p-6 mb-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  {match.home_logo ? (
                    <img src={match.home_logo} alt={match.home_team} className="w-16 h-16 object-contain" />
                  ) : (
                    <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center">
                      <span className="text-xl font-bold text-white">{
                        match.home_team.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 3)
                      }</span>
                    </div>
                  )}
                  <div className="text-center">
                    <div className="font-heading text-3xl font-bold text-primary mb-1">
                      {match.home_score} - {match.away_score}
                    </div>
                    {isLive && (
                      <div className="flex items-center gap-1 justify-center">
                        <div className="w-1.5 h-1.5 bg-live rounded-full animate-pulse-live"></div>
                        <span className="text-xs text-live font-body font-semibold">LIVE</span>
                      </div>
                    )}
                  </div>
                  {match.away_logo ? (
                    <img src={match.away_logo} alt={match.away_team} className="w-16 h-16 object-contain" />
                  ) : (
                    <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center">
                      <span className="text-xl font-bold text-white">{
                        match.away_team.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 3)
                      }</span>
                    </div>
                  )}
                </div>
              </div>

              <h1 className="font-heading text-2xl md:text-3xl font-bold text-white mb-6">
                {match.home_team} vs {match.away_team}
              </h1>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm font-body">
                <div className="flex items-center gap-3 text-gray-400">
                  <Calendar className="w-4 h-4 text-primary" />
                  <span>{new Date(match.match_date).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</span>
                </div>

                <div className="flex items-center gap-3 text-gray-400">
                  <MapPin className="w-4 h-4 text-primary" />
                  <span>{match.country}</span>
                </div>

                <div className="flex items-center gap-3 text-gray-400">
                  <div className="w-4 h-4 flex items-center justify-center">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                  </div>
                  <span>{match.competition}</span>
                </div>

                <div className="flex items-center gap-3 text-gray-400">
                  <div className="w-4 h-4 flex items-center justify-center">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                  </div>
                  <span>Kick-off: {match.match_time}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:w-80">
            <h2 className="font-heading text-xl font-bold text-white mb-4">Upcoming Matches</h2>
            <div className="space-y-4">
              {upcomingMatches.length > 0 ? (
                upcomingMatches.map((m) => (
                  <Link key={m.id} to={`/watch/${m.id}`}>
                    <MatchCard match={m} compact />
                  </Link>
                ))
              ) : (
                <p className="font-body text-sm text-gray-400">No upcoming matches</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
