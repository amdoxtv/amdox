import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { Standing } from '../types/database';

const leagues = [
  { id: 'premier-league', name: 'Premier League', country: 'England' },
  { id: 'la-liga', name: 'La Liga', country: 'Spain' },
  { id: 'bundesliga', name: 'Bundesliga', country: 'Germany' },
  { id: 'serie-a', name: 'Serie A', country: 'Italy' },
  { id: 'ligue-1', name: 'Ligue 1', country: 'France' },
  { id: 'champions-league', name: 'Champions League', country: 'Europe' },
];

const sampleStandings: Standing[] = [
  { position: 1, team: 'Manchester City', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/e/eb/Manchester_City_FC_badge.svg/180px-Manchester_City_FC_badge.svg.png', played: 38, won: 28, drawn: 5, lost: 5, goalsFor: 89, goalsAgainst: 35, goalDifference: 54, points: 89 },
  { position: 2, team: 'Liverpool', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/0/0c/Liverpool_FC.svg/180px-Liverpool_FC.svg.png', played: 38, won: 26, drawn: 8, lost: 4, goalsFor: 78, goalsAgainst: 32, goalDifference: 46, points: 86 },
  { position: 3, team: 'Arsenal', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/5/53/Arsenal_FC.svg/180px-Arsenal_FC.svg.png', played: 38, won: 25, drawn: 7, lost: 6, goalsFor: 75, goalsAgainst: 38, goalDifference: 37, points: 82 },
  { position: 4, team: 'Chelsea', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/c/cc/Chelsea_FC.svg/198px-Chelsea_FC.svg.png', played: 38, won: 23, drawn: 8, lost: 7, goalsFor: 68, goalsAgainst: 40, goalDifference: 28, points: 77 },
  { position: 5, team: 'Manchester United', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/7/7a/Manchester_United_FC_crest.svg/180px-Manchester_United_FC_crest.svg.png', played: 38, won: 21, drawn: 9, lost: 8, goalsFor: 62, goalsAgainst: 45, goalDifference: 17, points: 72 },
  { position: 6, team: 'Tottenham', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/b/b4/Tottenham_Hotspur.svg/180px-Tottenham_Hotspur.svg.png', played: 38, won: 20, drawn: 7, lost: 11, goalsFor: 65, goalsAgainst: 50, goalDifference: 15, points: 67 },
  { position: 7, team: 'Newcastle', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/5/56/Newcastle_United_Logo.svg/180px-Newcastle_United_Logo.svg.png', played: 38, won: 19, drawn: 6, lost: 13, goalsFor: 58, goalsAgainst: 48, goalDifference: 10, points: 63 },
  { position: 8, team: 'Brighton', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/f/fc/Brighton_%26_Hove_Albion_logo.svg/180px-Brighton_%26_Hove_Albion_logo.svg.png', played: 38, won: 17, drawn: 9, lost: 12, goalsFor: 55, goalsAgainst: 50, goalDifference: 5, points: 60 },
  { position: 9, team: 'Aston Villa', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/f/f9/Aston_Villa_FC_crest_%282016%29.svg/180px-Aston_Villa_FC_crest_%282016%29.svg.png', played: 38, won: 16, drawn: 8, lost: 14, goalsFor: 52, goalsAgainst: 51, goalDifference: 1, points: 56 },
  { position: 10, team: 'West Ham', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/c/c2/West_Ham_United_FC_logo.svg/180px-West_Ham_United_FC_logo.svg.png', played: 38, won: 15, drawn: 8, lost: 15, goalsFor: 48, goalsAgainst: 52, goalDifference: -4, points: 53 },
  { position: 11, team: 'Brentford', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/5/5a/Brentford_FC_crest.svg/180px-Brentford_FC_crest.svg.png', played: 38, won: 14, drawn: 8, lost: 16, goalsFor: 45, goalsAgainst: 55, goalDifference: -10, points: 50 },
  { position: 12, team: 'Crystal Palace', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/4/49/Crystal_Palace_FC_logo.svg/180px-Crystal_Palace_FC_logo.svg.png', played: 38, won: 13, drawn: 9, lost: 16, goalsFor: 42, goalsAgainst: 58, goalDifference: -16, points: 48 },
  { position: 13, team: 'Everton', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/7/7c/Everton_FC_logo.svg/188px-Everton_FC_logo.svg.png', played: 38, won: 12, drawn: 8, lost: 18, goalsFor: 40, goalsAgainst: 60, goalDifference: -20, points: 44 },
  { position: 14, team: 'Fulham', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/e/eb/Fulham_FC_%282018%29.svg/180px-Fulham_FC_%282018%29.svg.png', played: 38, won: 11, drawn: 9, lost: 18, goalsFor: 38, goalsAgainst: 62, goalDifference: -24, points: 42 },
  { position: 15, team: 'Bournemouth', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/e/e5/AFC_Bournemouth_%282018%29.svg/180px-AFC_Bournemouth_%282018%29.svg.png', played: 38, won: 10, drawn: 10, lost: 18, goalsFor: 36, goalsAgainst: 65, goalDifference: -29, points: 40 },
  { position: 16, team: 'Wolves', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/f/fc/Wolverhampton_Wanderers_logo.svg/180px-Wolverhampton_Wanderers_logo.svg.png', played: 38, won: 9, drawn: 10, lost: 19, goalsFor: 35, goalsAgainst: 68, goalDifference: -33, points: 37 },
  { position: 17, team: 'Nottingham Forest', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/e/e5/Nottingham_Forest_F.C._logo.svg/180px-Nottingham_Forest_F.C._logo.svg.png', played: 38, won: 8, drawn: 9, lost: 21, goalsFor: 32, goalsAgainst: 72, goalDifference: -40, points: 33 },
  { position: 18, team: 'Luton Town', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/c/Cambridge_United_FC.svg/180px-Cambridge_United_FC.svg.png', played: 38, won: 7, drawn: 8, lost: 23, goalsFor: 30, goalsAgainst: 78, goalDifference: -48, points: 29 },
  { position: 19, team: 'Burnley', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/4/4c/Burnley_FC_Logo.svg/180px-Burnley_FC_Logo.svg.png', played: 38, won: 6, drawn: 8, lost: 24, goalsFor: 28, goalsAgainst: 80, goalDifference: -52, points: 26 },
  { position: 20, team: 'Sheffield United', logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/4/4a/Sheffield_United_FC_logo.svg/180px-Sheffield_United_FC_logo.svg.png', played: 38, won: 5, drawn: 7, lost: 26, goalsFor: 25, goalsAgainst: 85, goalDifference: -60, points: 22 },
];

function getRowColor(position: number): string {
  if (position <= 4) return 'border-l-4 border-l-green-500';
  if (position <= 6) return 'border-l-4 border-l-blue-500';
  if (position >= 18) return 'border-l-4 border-l-red-500';
  return '';
}

function getPositionBadgeStyle(position: number): string {
  if (position <= 4) return 'bg-green-500/20 text-green-400';
  if (position <= 6) return 'bg-blue-500/20 text-blue-400';
  if (position >= 18) return 'bg-red-500/20 text-red-400';
  return 'bg-gray-500/20 text-gray-400';
}

export function StandingsPage() {
  const [selectedLeague, setSelectedLeague] = useState(leagues[0]);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <h1 className="font-heading text-3xl md:text-4xl font-bold text-white">Standings</h1>

        <div className="relative">
          <button
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="flex items-center gap-3 bg-surface hover:bg-surface/80 border border-white/10 rounded-lg px-4 py-3 transition-colors"
          >
            <span className="font-body text-white">{selectedLeague.name}</span>
            <span className="text-sm font-body text-gray-400">({selectedLeague.country})</span>
            <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
          </button>

          {isDropdownOpen && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-surface border border-white/10 rounded-lg overflow-hidden z-20">
              {leagues.map((league) => (
                <button
                  key={league.id}
                  onClick={() => {
                    setSelectedLeague(league);
                    setIsDropdownOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-4 py-3 transition-colors ${
                    league.id === selectedLeague.id ? 'bg-primary/20 text-primary' : 'hover:bg-white/5 text-white'
                  }`}
                >
                  <span className="font-body text-sm">{league.name}</span>
                  <span className="text-xs text-gray-400">{league.country}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="bg-surface rounded-xl overflow-hidden border border-white/10">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-surface/50 border-b border-white/10">
                <th className="text-left px-4 py-4 font-body text-xs font-semibold text-gray-400 uppercase w-12">Pos</th>
                <th className="text-left px-4 py-4 font-body text-xs font-semibold text-gray-400 uppercase">Team</th>
                <th className="text-center px-3 py-4 font-body text-xs font-semibold text-gray-400 uppercase w-12">P</th>
                <th className="text-center px-3 py-4 font-body text-xs font-semibold text-gray-400 uppercase w-12">W</th>
                <th className="text-center px-3 py-4 font-body text-xs font-semibold text-gray-400 uppercase w-12">D</th>
                <th className="text-center px-3 py-4 font-body text-xs font-semibold text-gray-400 uppercase w-12">L</th>
                <th className="text-center px-3 py-4 font-body text-xs font-semibold text-gray-400 uppercase w-12">GF</th>
                <th className="text-center px-3 py-4 font-body text-xs font-semibold text-gray-400 uppercase w-12">GA</th>
                <th className="text-center px-3 py-4 font-body text-xs font-semibold text-gray-400 uppercase w-12">GD</th>
                <th className="text-center px-4 py-4 font-body text-xs font-semibold text-primary uppercase w-16">Pts</th>
              </tr>
            </thead>
            <tbody>
              {sampleStandings.map((standing) => (
                <tr
                  key={standing.position}
                  className={`border-b border-white/5 hover:bg-surface/30 transition-colors ${getRowColor(standing.position)}`}
                >
                  <td className="px-4 py-4">
                    <div className={`w-6 h-6 rounded flex items-center justify-center font-body text-xs font-semibold ${getPositionBadgeStyle(standing.position)}`}>
                      {standing.position}
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={standing.logo}
                        alt={standing.team}
                        className="w-6 h-6 object-contain"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                      <span className="font-body text-sm text-white">{standing.team}</span>
                    </div>
                  </td>
                  <td className="text-center px-3 py-4 font-body text-sm text-gray-300">{standing.played}</td>
                  <td className="text-center px-3 py-4 font-body text-sm text-gray-300">{standing.won}</td>
                  <td className="text-center px-3 py-4 font-body text-sm text-gray-300">{standing.drawn}</td>
                  <td className="text-center px-3 py-4 font-body text-sm text-gray-300">{standing.lost}</td>
                  <td className="text-center px-3 py-4 font-body text-sm text-gray-300">{standing.goalsFor}</td>
                  <td className="text-center px-3 py-4 font-body text-sm text-gray-300">{standing.goalsAgainst}</td>
                  <td className="text-center px-3 py-4 font-body text-sm text-gray-300">
                    <span className={standing.goalDifference > 0 ? 'text-green-400' : standing.goalDifference < 0 ? 'text-red-400' : 'text-gray-400'}>
                      {standing.goalDifference > 0 ? '+' : ''}{standing.goalDifference}
                    </span>
                  </td>
                  <td className="text-center px-4 py-4 font-body text-sm font-bold text-primary">{standing.points}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-6">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-green-500 rounded"></div>
          <span className="font-body text-sm text-gray-400">Champions League</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-blue-500 rounded"></div>
          <span className="font-body text-sm text-gray-400">Europa League</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-red-500 rounded"></div>
          <span className="font-body text-sm text-gray-400">Relegation</span>
        </div>
      </div>
    </div>
  );
}
