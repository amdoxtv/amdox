export type MatchStatus = 'upcoming' | 'live' | 'finished';

export interface Match {
  id: string;
  home_team: string;
  away_team: string;
  home_logo: string;
  away_logo: string;
  match_date: string;
  match_time: string;
  competition: string;
  country: string;
  status: MatchStatus;
  stream_url: string;
  is_premium: boolean;
  home_score: number;
  away_score: number;
  created_at: string;
}

export interface Standing {
  position: number;
  team: string;
  logo: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDifference: number;
  points: number;
}

export interface NewsItem {
  id: string;
  title: string;
  excerpt: string;
  image: string;
  date: string;
  category: string;
}
