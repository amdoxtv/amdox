import React from 'react';

export function MatchCardSkeleton() {
  return (
    <div className="bg-surface rounded-xl p-4 md:p-6 animate-pulse">
      <div className="flex items-center justify-between gap-4">
        <div className="flex flex-col items-center flex-1">
          <div className="w-16 h-16 md:w-20 md:h-20 bg-gray-700 rounded-full mb-2"></div>
          <div className="w-20 h-4 bg-gray-700 rounded mb-2"></div>
          <div className="w-12 h-6 bg-gray-700 rounded"></div>
        </div>

        <div className="flex flex-col items-center justify-center min-w-[80px] md:min-w-[120px]">
          <div className="w-16 h-3 bg-gray-700 rounded mb-2"></div>
          <div className="w-20 h-4 bg-gray-700 rounded mb-2"></div>
          <div className="w-16 h-6 bg-gray-700 rounded"></div>
        </div>

        <div className="flex flex-col items-center flex-1">
          <div className="w-16 h-16 md:w-20 md:h-20 bg-gray-700 rounded-full mb-2"></div>
          <div className="w-20 h-4 bg-gray-700 rounded mb-2"></div>
          <div className="w-12 h-6 bg-gray-700 rounded"></div>
        </div>
      </div>
    </div>
  );
}

export function TableSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="w-full">
      <div className="bg-surface rounded-xl overflow-hidden">
        <div className="grid grid-cols-12 gap-4 p-4 bg-surface/50 text-xs font-body text-gray-400">
          {[...Array(12)].map((_, i) => (
            <div key={i} className="h-3 bg-gray-700 rounded"></div>
          ))}
        </div>
        {[...Array(rows)].map((_, i) => (
          <div key={i} className="border-t border-white/5 p-4 animate-pulse">
            <div className="grid grid-cols-12 gap-4">
              {[...Array(12)].map((_, j) => (
                <div key={j} className="h-4 bg-gray-700 rounded"></div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function HeroSkeleton() {
  return (
    <div className="relative h-[400px] md:h-[500px] bg-gradient-to-b from-surface to-background animate-pulse">
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="w-24 h-24 bg-gray-700 rounded-full mb-4"></div>
        <div className="w-48 h-8 bg-gray-700 rounded mb-6"></div>
        <div className="flex items-center gap-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="w-16 h-16 bg-gray-700 rounded"></div>
          ))}
        </div>
      </div>
    </div>
  );
}
