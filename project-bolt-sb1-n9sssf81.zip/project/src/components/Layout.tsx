import React from 'react';
import { Outlet } from 'react-router-dom';
import { DesktopNav, MobileNav, MobileHeader } from './Navigation';

export function Layout() {
  return (
    <div className="min-h-screen bg-background">
      <DesktopNav />
      <MobileHeader />
      <main className="pb-20 md:pb-0">
        <Outlet />
      </main>
      <MobileNav />
    </div>
  );
}
