import React from 'react';
import { Lock, Play } from 'lucide-react';
import { Match } from '../types/database';
import { useNavigate } from 'react-router-dom';

interface MatchCardProps {
  match: Match;
  showDate?: boolean;
  compact?: boolean;
}

function getInitials(name: string): string {
  return name
    .split(' ')
    .map(word => word[0])
    .join('')
    .toUpperCase()
    .slice(0, 3);
}

function getTeamColor(name: string): string {
  const colors = [
    'bg-blue-600',
    'bg-red-600',
    'bg-green-600',
    'bg-yellow-600',
    'bg-purple-600',
    'bg-pink-600',
    'bg-orange-600',
  ];
  const index = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return colors[index % colors.length];
}

function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  const options: Intl.DateTimeFormatOptions = { day: '2-digit', month: 'short' };
  return date.toLocaleDateString('fr-FR', options);
}

export function MatchCard({ match, showDate = true, compact = false }: MatchCardProps) {
  const navigate = useNavigate();
  const isLive = match.status === 'live';
  const isFinished = match.status === 'finished';

  const handleClick = () => {
    if (!match.is_premium || match.status === 'finished') {
      navigate(`/watch/${match.id}`);
    }
  };

  if (compact) {
    return (
      <div
        onClick={handleClick}
        className="bg-surface rounded-lg p-3 hover:bg-surface/80 transition-colors cursor-pointer relative overflow-hidden"
      >
        {match.is_premium && match.status !== 'finished' && (
          <div className="absolute inset-0 bg-background/60 backdrop-blur-sm flex items-center justify-center z-10">
            <Lock className="w-6 h-6 text-accent" />
          </div>
        )}

        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            {match.home_logo ? (
              <img src={match.home_logo} alt={match.home_team} className="w-6 h-6 object-contain" />
            ) : (
              <div className={`w-6 h-6 ${getTeamColor(match.home_team)} rounded-full flex items-center justify-center`}>
                <span className="text-[8px] font-bold text-white">{getInitials(match.home_team)}</span>
              </div>
            )}
            <span className="font-body text-xs truncate">{match.home_team}</span>
          </div>

          <div className="flex flex-col items-center min-w-[50px]">
            {isLive && (
              <div className="flex items-center gap-1 mb-1">
                <div className="w-2 h-2 bg-live rounded-full animate-pulse-live"></div>
                <span className="text-[10px] font-bold text-live">LIVE</span>
              </div>
            )}
            <span className="font-heading font-bold text-sm text-white">
              {match.home_score} - {match.away_score}
            </span>
            <span className="text-[10px] text-gray-400">{match.match_time}</span>
          </div>

          <div className="flex items-center gap-2 flex-1 min-w-0 justify-end">
            <span className="font-body text-xs truncate">{match.away_team}</span>
            {match.away_logo ? (
              <img src={match.away_logo} alt={match.away_team} className="w-6 h-6 object-contain" />
            ) : (
              <div className={`w-6 h-6 ${getTeamColor(match.away_team)} rounded-full flex items-center justify-center`}>
                <span className="text-[8px] font-bold text-white">{getInitials(match.away_team)}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      onClick={handleClick}
      className="bg-surface rounded-xl p-4 md:p-6 hover:bg-surface/80 transition-all cursor-pointer relative overflow-hidden group hover:shadow-lg hover:shadow-primary/10"
    >
      {match.is_premium && match.status !== 'finished' && (
        <div className="absolute inset-0 bg-background/60 backdrop-blur-sm flex items-center justify-center z-10">
          <div className="flex flex-col items-center gap-2">
            <Lock className="w-8 h-8 text-accent" />
            <span className="text-sm font-body text-accent">Premium</span>
          </div>
        </div>
      )}

      {isLive && (
        <div className="absolute top-2 right-2 flex items-center gap-1 bg-live/20 px-2 py-1 rounded-full z-20">
          <div className="w-2 h-2 bg-live rounded-full animate-pulse-live"></div>
          <span className="text-xs font-bold text-live">LIVE</span>
        </div>
      )}

      <div className="flex items-center justify-between gap-4">
        <div className="flex flex-col items-center flex-1">
          {match.home_logo ? (
            <img src={match.home_logo} alt={match.home_team} className="w-16 h-16 md:w-20 md:h-20 object-contain mb-2" />
          ) : (
            <div className={`w-16 h-16 md:w-20 md:h-20 ${getTeamColor(match.home_team)} rounded-full flex items-center justify-center mb-2`}>
              <span className="text-lg md:text-xl font-bold text-white">{getInitials(match.home_team)}</span>
            </div>
          )}
          <span className="font-body text-sm md:text-base text-center font-medium">{match.home_team}</span>
          {(isLive || isFinished) && (
            <span className="font-heading text-2xl md:text-3xl font-bold text-primary mt-1">{match.home_score}</span>
          )}
        </div>

        <div className="flex flex-col items-center justify-center min-w-[80px] md:min-w-[120px]">
          <span className="text-xs text-gray-400 mb-1">{match.competition}</span>
          {showDate && (
            <span className="text-sm font-body text-white mb-1">{formatDate(match.match_date)}</span>
          )}
          <span className="text-lg md:text-xl font-heading font-semibold text-white">{match.match_time}</span>
          {!isLive && !isFinished && (
            <Play className="w-6 h-6 text-primary mt-2 opacity-0 group-hover:opacity-100 transition-opacity" />
          )}
        </div>

        <div className="flex flex-col items-center flex-1">
          {match.away_logo ? (
            <img src={match.away_logo} alt={match.away_team} className="w-16 h-16 md:w-20 md:h-20 object-contain mb-2" />
          ) : (
            <div className={`w-16 h-16 md:w-20 md:h-20 ${getTeamColor(match.away_team)} rounded-full flex items-center justify-center mb-2`}>
              <span className="text-lg md:text-xl font-bold text-white">{getInitials(match.away_team)}</span>
            </div>
          )}
          <span className="font-body text-sm md:text-base text-center font-medium">{match.away_team}</span>
          {(isLive || isFinished) && (
            <span className="font-heading text-2xl md:text-3xl font-bold text-primary mt-1">{match.away_score}</span>
          )}
        </div>
      </div>
    </div>
  );
}
