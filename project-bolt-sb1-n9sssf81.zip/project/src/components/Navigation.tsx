import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Grid3X3, Trophy, Newspaper, User, Menu, X, Search } from 'lucide-react';
import { useState } from 'react';
import { Logo } from './Logo';
import { useAuth } from '../context/AuthContext';

const navLinks = [
  { path: '/', label: 'Home', icon: Home },
  { path: '/match', label: 'Match', icon: Grid3X3 },
  { path: '/classement', label: 'Classement', icon: Trophy },
  { path: '/news', label: 'News', icon: Newspaper },
];

export function DesktopNav() {
  const location = useLocation();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <nav className="hidden md:flex items-center justify-between px-8 py-4 bg-surface/80 backdrop-blur-lg border-b border-white/10 sticky top-0 z-50">
      <Link to="/" className="hover:opacity-80 transition-opacity">
        <Logo size="md" showText={false} />
      </Link>

      <div className="flex items-center gap-8">
        {navLinks.map(({ path, label }) => {
          const isActive = location.pathname === path;
          return (
            <Link
              key={path}
              to={path}
              className={`font-body text-sm transition-colors ${
                isActive ? 'text-primary' : 'text-gray-300 hover:text-white'
              }`}
            >
              {label}
            </Link>
          );
        })}
      </div>

      <div className="flex items-center gap-4">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search matches..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-background/50 border border-white/10 rounded-full pl-10 pr-4 py-2 text-sm font-body focus:outline-none focus:border-primary/50 w-48"
          />
        </div>

        {user ? (
          <Link
            to="/admin"
            className="flex items-center gap-2 bg-primary/20 hover:bg-primary/30 px-4 py-2 rounded-lg transition-colors"
          >
            <User className="w-4 h-4 text-primary" />
            <span className="font-body text-sm text-primary">Admin</span>
          </Link>
        ) : (
          <Link
            to="/admin/login"
            className="text-gray-300 hover:text-white transition-colors"
          >
            <User className="w-5 h-5" />
          </Link>
        )}
      </div>
    </nav>
  );
}

export function MobileNav() {
  const location = useLocation();
  const { user } = useAuth();

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-surface/95 backdrop-blur-lg border-t border-white/10 z-50">
      <div className="flex items-center justify-around py-2">
        {navLinks.map(({ path, label, icon: Icon }) => {
          const isActive = location.pathname === path;
          return (
            <Link
              key={path}
              to={path}
              className="flex flex-col items-center gap-1 px-4 py-2 transition-colors"
            >
              <Icon
                className={`w-5 h-5 ${isActive ? 'text-primary' : 'text-gray-400'}`}
              />
              <span
                className={`text-xs font-body ${
                  isActive ? 'text-primary' : 'text-gray-400'
                }`}
              >
                {label}
              </span>
            </Link>
          );
        })}
        <Link
          to={user ? '/admin' : '/admin/login'}
          className="flex flex-col items-center gap-1 px-4 py-2 transition-colors"
        >
          <User
            className={`w-5 h-5 ${
              location.pathname.startsWith('/admin') ? 'text-primary' : 'text-gray-400'
            }`}
          />
          <span
            className={`text-xs font-body ${
              location.pathname.startsWith('/admin') ? 'text-primary' : 'text-gray-400'
            }`}
          >
            Admin
          </span>
        </Link>
      </div>
    </div>
  );
}

export function MobileHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  return (
    <div className="md:hidden sticky top-0 z-50 bg-surface/80 backdrop-blur-lg border-b border-white/10 px-4 py-4">
      <div className="flex items-center justify-between">
        <Link to="/" className="hover:opacity-80 transition-opacity">
          <Logo size="sm" showText={true} />
        </Link>

        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="text-white p-2"
        >
          {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {isMenuOpen && (
        <div className="absolute top-full left-0 right-0 bg-surface border-b border-white/10 py-4 animate-slide-in">
          <div className="flex flex-col gap-4 px-4">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search matches..."
                className="bg-background/50 border border-white/10 rounded-full pl-10 pr-4 py-2 text-sm font-body focus:outline-none focus:border-primary/50 w-full"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
