import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export function Logo({ size = 'md', showText = true }: LogoProps) {
  const dimensions = {
    sm: { box: 'w-8 h-8', tv: 'text-xs', amdox: 'text-[8px]' },
    md: { box: 'w-10 h-10', tv: 'text-sm', amdox: 'text-[9px]' },
    lg: { box: 'w-14 h-14', tv: 'text-lg', amdox: 'text-[10px]' },
  };

  const { box, tv, amdox } = dimensions[size];

  return (
    <div className="flex items-center gap-2">
      <div className={`${box} bg-background rounded-lg border border-primary/30 flex flex-col items-center justify-center`}>
        <span className={`font-heading font-bold text-primary ${tv}`}>TV</span>
        {showText && <span className={`font-heading text-accent tracking-wider ${amdox}`}>AMDOX</span>}
      </div>
      {showText && size === 'lg' && (
        <div className="hidden md:block">
          <span className="font-heading font-bold text-primary text-2xl">AMDOX</span>
          <span className="font-heading text-accent text-sm ml-1">TV</span>
        </div>
      )}
    </div>
  );
}
